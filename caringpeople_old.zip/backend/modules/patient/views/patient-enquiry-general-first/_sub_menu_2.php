<?php

use yii\helpers\Html;
?>

<ul class="nav nav-tabs">
        <li class="active">
                <a href="#home-12" data-toggle="tab"><span class="visible-xs"><i class="linecons-note hidden-xs"></i></span>
                        <i class="linecons-note"></i><span class="hidden-xs span-font-size">REMARKS</span></a>
        </li>

        <li>
                <a href="#profile-13" data-toggle="tab"><span class="visible-xs"><i class="fa fa-tasks hidden-xs"></i></span>
                        <i class="fa fa-tasks"></i> <span class="hidden-xs span-font-size">  FOLLOWUPS</span></a>
        </li>
</ul>