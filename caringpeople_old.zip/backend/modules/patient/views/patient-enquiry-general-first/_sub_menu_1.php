<?php

use yii\helpers\Html;
?>

<ul class="nav nav-tabs">
        <li class="active">
                <a href="#home-4" data-toggle="tab"><span class="visible-xs"><i class="fa fa-book hidden-xs"></i></span>
                        <i class="fa fa-book"></i><span class="hidden-xs span-font-size">GENERAL INFORMATION</span></a>
        </li>

        <li>
                <a href="#profile-4" data-toggle="tab"><span class="visible-xs"><i class="fa-envelope-o hidden-xs"></i></span>
                        <i class="fa-envelope-o"></i> <span class="hidden-xs span-font-size">  PATIENT INFORMATION</span></a>
        </li>
</ul>