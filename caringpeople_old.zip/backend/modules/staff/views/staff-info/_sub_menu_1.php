<?php

use yii\helpers\Html;
?>

<ul class="nav nav-tabs">
        <li class="active">
                <a href="#home-3" data-toggle="tab"><span class="visible-xs"><i class="fa-envelope-o hidden-xs"></i></span>
                        <i class="fa-envelope-o"></i><span class="hidden-xs span-font-size">  ENQUIRY</span></a>
        </li>


        <li>
                <a href="#profile-3" data-toggle="tab"><span class="visible-xs"><i class="fa-info hidden-xs"></i></span>
                        <i class="fa-info"></i> <span class="hidden-xs span-font-size"> OTHER INFORMATION</span></a>
        </li>

        <li>
                <a href="#profile-4" data-toggle="tab"><span class="visible-xs"><i class="linecons-pencil hidden-xs"></i></span>
                        <i class="linecons-pencil"></i><span class="hidden-xs span-font-size"> INTERVIEW INFORMATION</span></a>
        </li>

        <li>
                <a href="#profile-5" data-toggle="tab"><span class="visible-xs"><i class="fa fa-inr hidden-xs"></i></span>
                        <i class="fa fa-inr"></i><span class="hidden-xs span-font-size"> SALARY DETAILS</span></a>
        </li>
</ul>