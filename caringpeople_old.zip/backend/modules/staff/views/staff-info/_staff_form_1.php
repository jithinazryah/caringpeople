<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel common\models\EnquirySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
if (Yii::$app->controller->action->id != 'editprofile') {
        $this->title = 'Staffs';
} else {
        $this->title = 'Update your Profile - ' . $model->staff_id;
}
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="enquiry-index">

        <div class="row">
                <div class="col-md-12">

                        <div class="panel panel-default">
                                <div class="panel-heading">
                                        <h3 class="panel-title"><?= Html::encode($this->title) ?></h3>

                                </div>
                                <?php if (Yii::$app->controller->action->id != 'editprofile') { ?>
                                        <?= Html::a('<i class="fa-th-list"></i><span> Manage Staff</span>', ['index'], ['class' => 'btn btn-warning  btn-icon btn-icon-standalone', 'style' => 'margin-top:10px;']) ?>
                                <?php } ?>
                                <?php if (!$model->isNewRecord && Yii::$app->controller->action->id != 'editprofile') { ?>
                                        <div id="rEset"> <a href="javascript:;" id="<?= $model->id; ?>"  class="ResetPassword" style="padding: 14px;
                                                            font-size: 14px;
                                                            font-weight: bold;
                                                            text-decoration: none;
                                                            float: right;">Reset Password</a></div>

                                <?php } ?>
                                <?php if (Yii::$app->controller->action->id != 'editprofile') { ?>
                                        <?=
                                        $this->render('_menus', [
                                            'model' => $model,
                                        ])
                                        ?>
                                <?php } ?>
                                <div class="panel-body panel_body_background" >

                                        <div class="tab-content tab_data_margin" >
                                                <?php if (Yii::$app->controller->action->id != 'editprofile') { ?>
                                                        <div class="tab-pane active" id="home-3">

                                                                <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>
                                                                <?=
                                                                $this->render('_form', [
                                                                    'model' => $model,
                                                                    'staff_edu' => $staff_edu,
                                                                    'form' => $form,
                                                                ])
                                                                ?>

                                                        </div>
                                                        <div class="tab-pane" id="profile-3">

                                                                <?=
                                                                $this->render('_other_info_form', [
                                                                    'model' => $other_info,
                                                                    'staff_previous_employer' => $staff_previous_employer,
                                                                    'form' => $form,
                                                                    'staffinfo' => $model,
                                                                    'staff_interview_second' => $staff_interview_second,
                                                                ])
                                                                ?>

                                                        </div>

                                                        <div class="tab-pane" id="profile-4">

                                                                <?=
                                                                $this->render('_staff_interview_info', [
                                                                    'staff_previous_employer' => $staff_previous_employer,
                                                                    'staff_interview_first' => $staff_interview_first,
                                                                    'staff_interview_second' => $staff_interview_second,
                                                                    'staff_interview_third' => $staff_interview_third,
                                                                    'staff_family' => $staff_family,
                                                                    'staffinfo' => $model,
                                                                    'form' => $form,
                                                                ])
                                                                ?>
                                                        </div>

                                                        <div class="tab-pane" id="profile-5">

                                                                <?=
                                                                $this->render('salary_details', [
                                                                    'staff_interview_first' => $staff_interview_first,
                                                                    'staff_interview_second' => $staff_interview_second,
                                                                    'staff_interview_third' => $staff_interview_third,
                                                                    'staff_family' => $staff_family,
                                                                    'staffinfo' => $model,
                                                                    'staff_salary' => $staff_salary,
                                                                    'form' => $form,
                                                                ])
                                                                ?>
                                                                <?php ActiveForm::end(); ?>
                                                        </div>

                                                        <?php if (!$model->isNewRecord) { ?>
                                                                <div class="tab-pane" id="profile-12">
                                                                        <?=
                                                                        $this->render('remarks', [
                                                                            'patient_info' => $model,
                                                                            'type' => 4,
                                                                        ])
                                                                        ?>
                                                                </div>

                                                                <div class="tab-pane" id="profile-13">

                                                                        <?=
                                                                        $this->render('followups', [
                                                                            'patient_info' => $model,
                                                                            'type' => 4,
                                                                        ])
                                                                        ?>

                                                                </div>

                                                        <?php } ?>


                                                <?php } else { ?>
                                                        <div class="tab-pane active" id="home-3">
                                                                <?php if (Yii::$app->session->hasFlash('error')): ?>
                                                                        <div class="alert alert-danger" role="alert">
                                                                                <?= Yii::$app->session->getFlash('error') ?>
                                                                        </div>
                                                                <?php endif; ?>
                                                                <?php if (Yii::$app->session->hasFlash('success')): ?>
                                                                        <div class="alert alert-success" role="alert">
                                                                                <?= Yii::$app->session->getFlash('success') ?>
                                                                        </div>
                                                                <?php endif; ?>
                                                                <?=
                                                                $this->render('update', [
                                                                    'model' => $model,
                                                                    'staff_edu' => $staff_edu,
                                                                    'form' => $form,
                                                                ])
                                                                ?>

                                                        </div>
                                                <?php } ?>

                                        </div>









                                </div>
                        </div>
                </div>
        </div>
</div>

<script>
//        $('#form_button').click(function (e) { // using click function
//                // on contact form submit button
//                e.preventDefault(); // stop form from submitting right away
//
//                var error = false;
//                $(this).find('.required').each(function () {
//                        if ($(this).val().length < 1) {
//                                error = true;
//                        }
//                });
//                if (error == false) {
//
//                        var Id = $('.tab-pane.active').attr('id');
//                        $('#'.Id).removeClass('active');
//                        $('#home-3').addClass('active'); // you submit form
//                        $("#w0").submit();
//                }
//                if (!error) {
//                        return true;
//                }
//
//        });
        $('.ResetPassword').on('click', function () {
                $('#user_id').val(this.id);
                $('#modal-reset').modal('show', {backdrop: 'static'});
        });
        $(document).on('submit', '#reset_password_form', function (e) {

                //$('#modal-reset').modal('hide');
                var newpassword = $('#new-password').val();
                var confirmpassword = $('#confirm-password').val();
                var userid = $('#user_id').val();
                if (newpassword === confirmpassword) {
                        showLoader();
                        $.ajax({
                                type: 'POST',
                                url: homeUrl + 'staff/staff-info/reset-password',
                                data: {password: newpassword, id: userid},
                                success: function (data) {
                                        //  $(".ResetPassword").append("<div>hello world</div>");
                                        $("#rEset").after("<b>Hello</b>");
                                }

                        });
                } else {
                        $('#modal-reset').modal('show', {backdrop: 'static'});
                        $('div.mismatch_error').text("Password Mismatch");
                        e.preventDefault();
                }


        }
        );


</script>


