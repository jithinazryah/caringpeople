<?php
Yii::setAlias('@paths', realpath(dirname(__FILE__) . '/../../uploads'));
return [
];
