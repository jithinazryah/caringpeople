<?php

namespace backend\modules\expenses\controllers;

use Yii;
use common\models\Expenses;
use common\models\ExpensesSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ExpensesController implements the CRUD actions for Expenses model.
 */
class ExpensesController extends Controller {

        /**
         * @inheritdoc
         */
        public function behaviors() {
                return [
                    'verbs' => [
                        'class' => VerbFilter::className(),
                        'actions' => [
                            'delete' => ['POST'],
                        ],
                    ],
                ];
        }

        /**
         * Lists all Expenses models.
         * @return mixed
         */
        public function actionIndex() {
                $searchModel = new ExpensesSearch();
                $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
                $query = $searchModel::find();
                if (!empty(Yii::$app->request->queryParams['ExpensesSearch']['date'])) {
                        list($from, $to) = explode(' - ', Yii::$app->request->queryParams['ExpensesSearch']['date']);
                        $sum = Expenses::find()->where(['BETWEEN', 'date', $from, $to])->sum('amount');
                } else {
                        $sum = Expenses::find()->sum('amount');
                }

                return $this->render('index', [
                            'searchModel' => $searchModel,
                            'dataProvider' => $dataProvider,
                            'sum' => $sum,
                ]);
        }

        /**
         * Displays a single Expenses model.
         * @param integer $id
         * @return mixed
         */
        public function actionView($id) {
                return $this->render('view', [
                            'model' => $this->findModel($id),
                ]);
        }

        /**
         * Creates a new Expenses model.
         * If creation is successful, the browser will be redirected to the 'view' page.
         * @return mixed
         */
        public function actionCreate() {
                $model = new Expenses();

                if ($model->load(Yii::$app->request->post()) && Yii::$app->SetValues->Attributes($model) && $model->validate()) {
                        $model->date = date('Y-m-d', strtotime($model->date));
                        if ($model->save())
                                return $this->redirect(['index']);
                }
                return $this->render('create', [
                            'model' => $model,
                ]);
        }

        /**
         * Updates an existing Expenses model.
         * If update is successful, the browser will be redirected to the 'view' page.
         * @param integer $id
         * @return mixed
         */
        public function actionUpdate($id) {
                $model = $this->findModel($id);

                if ($model->load(Yii::$app->request->post()) && Yii::$app->SetValues->Attributes($model) && $model->validate()) {
                        $model->date = date('Y-m-d', strtotime($model->date));
                        if ($model->save())
                                return $this->redirect(['index']);
                }
                return $this->render('update', [
                            'model' => $model,
                ]);
        }

        /**
         * Deletes an existing Expenses model.
         * If deletion is successful, the browser will be redirected to the 'index' page.
         * @param integer $id
         * @return mixed
         */
        public function actionDelete($id) {
                $this->findModel($id)->delete();

                return $this->redirect(['index']);
        }

        /**
         * Finds the Expenses model based on its primary key value.
         * If the model is not found, a 404 HTTP exception will be thrown.
         * @param integer $id
         * @return Expenses the loaded model
         * @throws NotFoundHttpException if the model cannot be found
         */
        protected function findModel($id) {
                if (($model = Expenses::findOne($id)) !== null) {
                        return $model;
                } else {
                        throw new NotFoundHttpException('The requested page does not exist.');
                }
        }

}
